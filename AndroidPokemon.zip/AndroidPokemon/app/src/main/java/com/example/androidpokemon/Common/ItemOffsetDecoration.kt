package com.example.androidpokemon.Common

import android.content.Context
import android.graphics.Rect
import android.support.annotation.DimenRes
import android.support.v7.widget.RecyclerView
import android.view.View

import io.reactivex.annotations.NonNull

class ItemOffsetDecoration(private val itemoffset: Int) : RecyclerView.ItemDecoration() {

    constructor(@NonNull context: Context, @DimenRes dimens: Int) : this(context.resources.getDimensionPixelSize(dimens)) {

    }

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        super.getItemOffsets(outRect, view, parent, state)
        outRect.set(itemoffset, itemoffset, itemoffset, itemoffset)

    }


}
