package com.example.androidpokemon.Interface

import android.view.View

interface IItemClickListener {

    fun OnClick(view: View, position: Int)


}
