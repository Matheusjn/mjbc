package com.example.androidpokemon

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentTransaction
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.view.View

import com.example.androidpokemon.Common.Common
import com.example.androidpokemon.Model.Pokemon

class MainActivity : AppCompatActivity() {

    internal lateinit var toolbar: Toolbar

    internal var showDetail: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action!!.toString() == Common.KEY_ENABLE_HOME) {
                supportActionBar!!.setDisplayHomeAsUpEnabled(true) //ativar o botao voltar na barra de ferramentas
                supportActionBar!!.setDisplayHomeAsUpEnabled(true) //também

                //Substituir Fragment
                val detailFragment = PokemonDetail.getInstance()
                val num = intent.getStringExtra("num")
                val bundle = Bundle()
                bundle.putString("num", num)
                detailFragment.arguments = bundle

                val fragmentTransaction = supportFragmentManager.beginTransaction()
                fragmentTransaction.replace(R.id.list_pokemon_fragment, detailFragment)
                fragmentTransaction.addToBackStack("detail")
                fragmentTransaction.commit()


                //Definir o nome do pokemon para a barra de ferramentas
                val pokemon = Common.findPokemonByNum(num)
                toolbar.title = pokemon!!.name

            }
        }
    }


    internal var showEvolution: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action!!.toString() == Common.KEY_NUM_EVOLUTION) {


                //Substituir Fragment
                val detailFragment = PokemonDetail.getInstance()

                val bundle = Bundle()
                val num = intent.getStringExtra("num")
                bundle.putString("num", num)
                detailFragment.arguments = bundle

                val fragmentTransaction = supportFragmentManager.beginTransaction()
                fragmentTransaction.remove(detailFragment) //Remover o atual fragment
                fragmentTransaction.replace(R.id.list_pokemon_fragment, detailFragment)
                fragmentTransaction.addToBackStack("detail")
                fragmentTransaction.commit()


                //Definir o nome do pokemon para a barra de ferramentas
                val pokemon = Common.findPokemonByNum(num)
                toolbar.title = pokemon!!.name

            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        toolbar.title = "POKEMON LIST"
        setSupportActionBar(toolbar)

        //Registrar Broadcast
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(showDetail, IntentFilter(Common.KEY_ENABLE_HOME))
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(showEvolution, IntentFilter(Common.KEY_NUM_EVOLUTION))

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                toolbar.title = "POKEMON LIST"


                //Limpar todos os detalhes do fragment
                supportFragmentManager.popBackStack("detail", FragmentManager.POP_BACK_STACK_INCLUSIVE)


                supportActionBar!!.setDisplayHomeAsUpEnabled(false)
                supportActionBar!!.setDisplayHomeAsUpEnabled(false)
            }
            else -> {
            }
        }
        return true
    }

}
