package com.example.androidpokemon.Model

class Evolution {
    var num: String? = null
    var name: String? = null

    constructor() {}

    constructor(num: String, name: String) {
        this.num = num
        this.name = name
    }
}
