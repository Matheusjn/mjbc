package com.example.androidpokemon.Model

class Pokedex {
    var pokemon: List<Pokemon>? = null

    constructor() {}

    constructor(pokemon: List<Pokemon>) {
        this.pokemon = pokemon
    }
}