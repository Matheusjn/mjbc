package com.example.androidpokemon.Model

import android.content.Context
import android.content.Intent
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import com.bumptech.glide.Glide
import com.example.androidpokemon.Common.Common
import com.example.androidpokemon.Interface.IItemClickListener
import com.example.androidpokemon.R

class PokemonListAdapter(internal var context: Context, internal var pokemonList: List<Pokemon>) : RecyclerView.Adapter<PokemonListAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(context).inflate(R.layout.pokem_list_item, parent, false)
        return MyViewHolder(itemView)

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {


        //Carregar Imagem
        Glide.with(context).load(pokemonList[position].img).into(holder.pokemon_image)
        //Setar nome
        holder.pokemon_name.text = pokemonList[position].name

        //Evento
        holder.setiItemClickListener(object : IItemClickListener {
            override fun OnClick(view: View, position: Int) {
                //Toast.makeText(context,"Clique no Pokemon:"+pokemonList.get(position).getName(),Toast.LENGTH_LONG).show();

                LocalBroadcastManager.getInstance(context)
                        .sendBroadcast(Intent(Common.KEY_ENABLE_HOME).putExtra("num", pokemonList[position].num))
            }
        })

    }

    override fun getItemCount(): Int {
        return pokemonList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

        internal var pokemon_image: ImageView
        internal var pokemon_name: TextView

        internal lateinit var iItemClickListener: IItemClickListener

        fun setiItemClickListener(iItemClickListener: IItemClickListener) {
            this.iItemClickListener = iItemClickListener
        }

        init {

            pokemon_image = itemView.findViewById<View>(R.id.pokemon_image) as ImageView
            pokemon_name = itemView.findViewById<View>(R.id.txt_pokemon_name) as TextView

            itemView.setOnClickListener(this)
        }

        override fun onClick(view: View) {
            iItemClickListener.OnClick(view, adapterPosition)
        }
    }
}
