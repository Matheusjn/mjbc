package com.example.androidpokemon


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.androidpokemon.Model.PokemonListAdapter
import com.example.androidpokemon.Common.Common
import com.example.androidpokemon.Common.ItemOffsetDecoration
import com.example.androidpokemon.Model.Pokemon
import com.example.androidpokemon.Retrofit.IPokemonDex
import com.example.androidpokemon.Retrofit.RetrofitClient
import com.mancj.materialsearchbar.MaterialSearchBar

import java.util.ArrayList

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers


class PokemonList : Fragment() {

    internal var iPokemonDex: IPokemonDex
    internal var compositeDisposable = CompositeDisposable()
    internal lateinit var pokemon_list_recyclerview: RecyclerView

    internal lateinit var adapter: PokemonListAdapter
    internal lateinit var search_adapter: PokemonListAdapter
    internal var last_suggest: MutableList<String> = ArrayList()


    internal lateinit var searchBar: MaterialSearchBar

    init {
        val retrofit = RetrofitClient.getInstance()
        iPokemonDex = retrofit.create(IPokemonDex::class.java!!)
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.fragment_pokemon_list, container, false)

        pokemon_list_recyclerview = view.findViewById<View>(R.id.pokemon_list_recyclerview) as RecyclerView
        pokemon_list_recyclerview.setHasFixedSize(true)
        pokemon_list_recyclerview.layoutManager = GridLayoutManager(activity, 2)
        val itemOffsetDecoration = ItemOffsetDecoration(activity!!, R.dimen.spacing)
        pokemon_list_recyclerview.addItemDecoration(itemOffsetDecoration)


        //Setup SearchBar
        searchBar = view.findViewById<View>(R.id.search_bar) as MaterialSearchBar
        searchBar.setHint("Enter Pokemon name")
        searchBar.setCardViewElevation(10)
        searchBar.addTextChangeListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val suggest = ArrayList<String>()
                for (search in last_suggest) {
                    if (search.toLowerCase().contains(searchBar.text.toLowerCase()))
                        suggest.add(search)
                }
                searchBar.lastSuggestions = suggest

            }

            override fun afterTextChanged(s: Editable) {

            }
        })
        searchBar.setOnSearchActionListener(object : MaterialSearchBar.OnSearchActionListener {
            override fun onSearchStateChanged(enabled: Boolean) {
                if (!enabled)
                    pokemon_list_recyclerview.adapter = adapter //Retornar ao adapter padrão

            }

            override fun onSearchConfirmed(text: CharSequence) {
                startSeach(text)


            }

            override fun onButtonClicked(buttonCode: Int) {

            }
        })

        fetchData()



        return view
    }

    private fun startSeach(text: CharSequence) {
        if (Common.commonPokemonList.size > 0) {
            val result = ArrayList<Pokemon>()
            for (pokemon in Common.commonPokemonList)
                if (pokemon.name!!.toLowerCase().contains(text.toString().toLowerCase()))
                    result.add(pokemon)
            search_adapter = activity?.let { PokemonListAdapter(it, result) }!!
            pokemon_list_recyclerview.adapter = search_adapter
        }

    }

    private fun fetchData() {
        compositeDisposable.add(iPokemonDex.listPokemon
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { pokedex ->
                    Common.commonPokemonList = pokedex.pokemon!!
                    adapter = activity?.let { PokemonListAdapter(it, Common.commonPokemonList) }!!

                    pokemon_list_recyclerview.adapter = adapter
                    last_suggest.clear()

                    for (pokemon in Common.commonPokemonList)
                        pokemon.name?.let { last_suggest.add(it) }
                    searchBar.visibility = View.VISIBLE
                    searchBar.lastSuggestions = last_suggest
                }

        )
    }

    companion object {


        internal var instance: PokemonList? = null
        fun getInstance(): PokemonList {

            if (instance == null)
                instance = PokemonList()


            return instance as PokemonList

        }
    }


}
